The stm32f0xx.h and system_stm32f0xx.h files are from stsw-stm32048.zip, 
the folder:

	STM32F0xx_StdPeriph_Lib_V1.3.1/Libraries/CMSIS/Device/ST/STM32F0xx/Include

The cmsis_device.h is added for convenience.

