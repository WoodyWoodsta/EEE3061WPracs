/*
 * LED.h
 *
 *  Created on: 17 Feb 2015
 *      Author: Student
 */

#ifndef LED_H_
#define LED_H_

#include "stm32f0xx.h"
#include <stddef.h>
#include <stdint.h>

void init_leds(void);



#endif /* LED_H_ */
